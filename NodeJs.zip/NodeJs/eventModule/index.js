//Events Module
// Node.js has a built-in module, called "Events",
// where you can create-, fire-, and listen for- your own events.

//Example 1_ Registering for the event to be fired only one time using once.

//Example 2- Create an event emitter instance and register a couple of callbacks

//Example 3- Registering for the event with callback parameters

//creating a class
const EventEmitter = require("events");

//create object from class
const event = new EventEmitter();

// write what to do when event occurs
event.on("sayMyName", () => {
  console.log("Bharat");
});
event.on("sayMyName", () => {
  console.log("Kumar");
});
event.on("sayMyName", () => {
  console.log("Rawal");
});

// create an event and fire it
event.emit("sayMyName");

/// event.on('checkpage', (sc, msg)=>{
// console.log(`status code is ${sc} and the paege is ${msg}`)
//})

// event.emit("checkpage", 200, "ok")
