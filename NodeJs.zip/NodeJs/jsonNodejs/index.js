////JSON stands for JavaScript Notation.
//JSON is the lightweight format for storing and trasnporting data
// JSON is often used when data is sent from a server to a web page
const fs = require("fs");
const bioData = {
  name: "Bharat",
  age: 23,
  course: "NodeJs",
};

//to convert object into JSON, method
// const jsonData = JSON.stringify(bioData);
//JSON data can not be called as dot notation as in JS object

//to covert JSON into Object, method
// const objData = JSON.parse(jsonData)
// console.log(objData)

//Challenge
//1> Convert obj to JSON
//2> add the data into the new file
//3> read the file
//4> again covert the data in Object

//1>
const newJSON = JSON.stringify(bioData);

//2 // need to give file extension as json
// fs.writeFile("json1.json",newJSON, (err) => {
//   console.log("done");
// });

//3
fs.readFile("json1.json", "utf-8", (err, data) => {
  const newData = JSON.parse(data); //4
  console.log(newData);
  console.log(data);
});
