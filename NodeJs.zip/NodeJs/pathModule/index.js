const path = require("path");

// console.log(
//   path.dirname("C:/Users/DELL/Desktop/JavaScript/NodeJs/pathModule/index.js")
// );

// console.log(
//   path.extname("C:/Users/DELL/Desktop/JavaScript/NodeJs/pathModule/index.js")
// );
// console.log(
//   path.basename("C:/Users/DELL/Desktop/JavaScript/NodeJs/pathModule/index.js")
// );

// console.log(
//   path.parse("C:/Users/DELL/Desktop/JavaScript/NodeJs/pathModule/index.js")
// );

const mypath = path.parse(
  "C:/Users/DELL/Desktop/JavaScript/NodeJs/pathModule/index.js"
); // this comes as the object and provide whole path information

console.log(mypath.name);
c;