// node automaticlly wraps each file
// (function(){
//   const name = "vinod";
//   console.log(name)
// }) this a wrapper also known as IFFE
console.log(__dirname);
console.log(__filename)
 