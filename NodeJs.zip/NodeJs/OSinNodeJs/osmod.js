const os = require("os");
console.log(os.arch()); // provide architecure of the local machine

const freeMemory = os.freemem(); // provide information about the free memory
console.log(`${freeMemory / 1024 / 1024 / 1024}`);

const totalMemory = os.totalmem(); // provide information about the total memory
console.log(`${totalMemory / 1024 / 1024 / 1024}`);

console.log(os.hostname());
console.log(os.platform());
console.log(os.type());
