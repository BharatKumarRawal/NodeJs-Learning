// API tuts
//API is like a service from where we ask for data

const http = require("http");
const fs = require("fs");

newserver = http.createServer((req, res) => {
  const data = fs.readFileSync("userapi.json", "utf-8"); // load data once using Synchronous function
  const objDt = JSON.parse(data); // convert JSON to OBj
  if (req.url == "/") {
    res.end("Hello from the home side");
  } else if (req.url == "/about") {
    res.end("hello from the About us sides");
  } else if (req.url == "/userapi") {
    // reading the json data when the specific url is requested
    res.writeHead(200, { "Content-type": "application/json" }); // always give context on which type of data you are wroking with
    res.end(objDt[0].address.street);
  } else {
    res.writeHead(404, { "Content-type": "text/html" }); // to give information in response header
    res.end("<h1>404 page does not exist</h1>"); // can write html or provide html file
  }
});

newserver.listen(8000, "127.0.0.1", () => {
  console.log("listening at port 8000");
});
