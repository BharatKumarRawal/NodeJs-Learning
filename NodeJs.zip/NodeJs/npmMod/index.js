// npm should be initialized inside the  current root folder
//npm init
//pckg json file created automatically holding dependecies
// install required dependencies as require
// nodemon global npm installed using npm i nodemon -g

const chalk = require("chalk");
const validator = require("validator");

console.log(chalk.green.underline.inverse("success!"));
const mail = "bharat@bharat.com";
const res = validator.isEmail(mail);
console.log(res ? chalk.green.inverse(res) : chalk.red.inverse(res));
