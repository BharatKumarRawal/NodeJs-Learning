// creating custom modules
// importing custom modules

// const {add, sub} = require(file)  destructing of object
const oper = require("./oper");
console.log(oper.add(5, 5)); // taking add() as a property of oper
console.log(oper.sub(10, 5));
