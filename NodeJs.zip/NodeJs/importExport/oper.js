//each individual file in js is called module
//creating a function to add two numbers

// all the variables and function have private scope  and need to be exported to use it in other file
const add = (num1, num2) => {
  return num1 + num2;
};
const sub = (num1, num2) => {
  return num1 - num2;
};

module.exports.add = add;
module.exports.sub = sub; // making scope public // exporting as a object

// module.exports = {add, sub} // destructing
