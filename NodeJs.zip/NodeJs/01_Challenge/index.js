const fs = require("fs");

// Creates a file with given name if file is not alrady created and write data into it,

// fs.writeFileSync(
//   "bio.txt",
//   "Hello this is my first file created with the nodejs"
// );

//This appends the new data into the file without overwriting the previous data

// fs.appendFileSync(
//   "bio.txt",
//   "This is the appended data in Nodejs using appenfFileSync"
// );

// const dataFromFIle = fs.readFileSync("bio.txt"); // read buffer data from the file
// const newData = dataFromFIle.toString(); //converting buffer data into the string
// console.log(newData);

fs.renameSync("01_Challenge/mybio.txt", "01_Challenge/bio.txt");

// fs.unlinkSync("mybio.txt") it deltes the file
