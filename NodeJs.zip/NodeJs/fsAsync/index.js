const fs = require("fs");

// fs.writeFile("read.txt", "Today is awesome day: ", (err) => {
//   console.log("files is created");
//   console.log(err);
// });

// we pass them a function as an argument - a callback -
// that gets called when that task completes.
// the callback has an argument that tell you whether
//the operation is completed successfully
// now we need to day what to do when fs.writeFIle
//has completed (even if it's nothing), and start checking for errors

// fs.appendFile("read.txt", "this is the appened value using Async", (err) => {
//   console.log(err);
// });

// second argument is for encoding
//call back will have two arguments and first one should be err and second argument is the data
fs.readFile("read.txt", "utf-8", (err, data) => {
  console.log(data);
});
