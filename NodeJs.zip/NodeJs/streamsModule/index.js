// streams are objects that let you read data from a source or write daa to a destination in continuous fashion
// In node.js there are four types of streams

//Streaming means listening to music or watching video in real time, instead of downlaoding a file to your computer and watching it later
// Readable -- Stream which is used for read operation
// Writable -- Stream which is used for write operation
// Duplex -- Stream which can be used for both read and write operation
// Transform -- A type of duplex stream where the output is computed based on input
//
// stream.pipe() method is used to take a readbale stream and connect it to a writeable stream

// reading data as a strem // create a readble strea, // Handle stream events -> data, end, error, and finish

const fs = require("fs");
const http = require("http");

const server = http.createServer();

server.on("request", (req, res) => {
  // fs.readFile("input.txt", "utf-8", (err, data) => {
  //   if (err) {
  //     return console.error(err);
  //   }
  //   res.end(data);
  // });

  // 2nd way-streaming way
  const rstream = fs.createReadStream("input.txt"); // creating a readable stream

  // downlaoding the data chunk by chunk and writing them
  ////rstream.on("data", (chunkdata) => {
  /////res.write(chunkdata);
  // });
  // when there is no more data to downlaod we fire end
  //// rstream.on("end", () => {
  //   res.end();
  //// });
  //checking for error in streaming
  // rstream.on("error", (err) => {
  //   console.log(err);
  //   res.end("file not found");
  // });

  // 3rd way
  rstream.pipe(res); //read and write in simple way
});

server.listen(8000, "127.0.0.1");
