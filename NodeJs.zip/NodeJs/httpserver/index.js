// The http.createServer() method  includes request and response parameters which is supplied by Node.js
// the request object can be used to get information about the current http request
// e.g, url, request header, and data

// the response object can be used to send a response for a current HttP request

// if the response from the http server is supposed to be displayed as HTML,
// you should include an HTTP header with the correct content type:

//url module
//routing basic using

const http = require("http");

const server = http.createServer((req, res) => {
  // console.log(req.url);
  if (req.url == "/") {
    res.end("Hello from the home side");
  } else if (req.url == "/about") {
    res.end("hello from the About us sides");
  } else if (req.url == "/contact") {
    res.end("hello from the contact sides");
  } else {
    res.writeHead(404, { "Content-type": "text/html" }); // to give information in response header
    res.end("<h1>404 page does not exist</h1>"); // can write html or provide html file
  }
});

server.listen(8000, "127.0.0.1", () => {
  console.log("listening to port no 8000");
});
